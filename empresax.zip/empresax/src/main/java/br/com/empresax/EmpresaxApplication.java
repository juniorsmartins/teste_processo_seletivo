package br.com.empresax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpresaxApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpresaxApplication.class, args);
	}

}
